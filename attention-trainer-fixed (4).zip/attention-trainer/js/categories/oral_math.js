/* ── ORAL MATH ── */
CATS.oral_math = {
  name: 'Устный счёт', desc: 'Реши цепочку действий в уме',
  icon: '🧮', bg: '#faeeda', fg: '#633806',
  gen() {
    const lvl = getLvl();
    let parts, ans; // parts = [{val, label}] для отображения без промежуточных результатов

    if (lvl.id === 1) {
      const a = r(20)+5, b = r(15)+3, c = r(12)+2;
      const ops = [pick(['+','−']), pick(['+','−'])];
      const v1 = ops[0]==='+' ? a+b : a-b;
      ans = ops[1]==='+' ? v1+c : v1-c;
      parts = [{n:a},{op:ops[0]},{n:b},{op:ops[1]},{n:c}];
    } else if (lvl.id === 2) {
      const a = r(12)+3, b = r(8)+2, c = r(15)+5;
      const op2 = pick(['+','−']);
      ans = op2==='+' ? a*b+c : a*b-c;
      parts = [{n:a},{op:'×'},{n:b},{op:op2},{n:c}];
    } else if (lvl.id === 3) {
      const type = r(3);
      if (type === 0) {
        const a=r(8)+3, b=r(5)+2, c=r(6)+2, d=r(10)+3;
        const ops=[pick(['+','−']),pick(['+','−'])];
        const v1=a*b, v2=ops[0]==='+'?v1+c:v1-c;
        ans=ops[1]==='+'?v2+d:v2-d;
        parts=[{n:a},{op:'×'},{n:b},{op:ops[0]},{n:c},{op:ops[1]},{n:d}];
      } else if (type === 1) {
        const b=pick([2,3,4,5]), a=b*(r(8)+3), c=r(15)+5;
        const op=pick(['+','−']);
        ans=op==='+'?a/b+c:a/b-c;
        parts=[{n:a},{op:'÷'},{n:b},{op},{n:c}];
      } else {
        const a=r(6)+2, b=r(4)+2, c=r(4)+2;
        ans=a*b*c;
        parts=[{n:a},{op:'×'},{n:b},{op:'×'},{n:c}];
      }
    } else {
      const type = r(3);
      if (type === 0) {
        // a×b − c×d + e  (два независимых произведения)
        const a=r(9)+4, b=r(6)+3, c=r(6)+2, d=r(5)+2, e=r(12)+5;
        ans=a*b - c*d + e;
        parts=[{n:a},{op:'×'},{n:b},{op:'−'},{n:c},{op:'×'},{n:d},{op:'+'},{n:e}];
      } else if (type === 1) {
        // процент от числа
        const base=pick([100,200,150,80,60]);
        const pct=pick([10,20,25,50]);
        const add=r(20)+5;
        ans=base*pct/100+add;
        parts=[{pct},{n:base},{op:'+'},{n:add}];
      } else {
        // квадрат + цепочка
        const a=pick([7,8,9,11,12,13]);
        const b=r(20)+5, op=pick(['+','−']);
        ans=op==='+'?a*a+b:a*a-b;
        parts=[{sq:a},{op},{n:b}];
      }
    }

    // Строим HTML — только числа и операторы, без промежуточных результатов
    const html = parts.map(p => {
      if (p.op !== undefined) return `<span class="math-op">${p.op}</span>`;
      if (p.pct !== undefined) return `<span class="math-num">${p.pct}%</span><span class="math-op" style="font-size:15px"> от </span>`;
      if (p.sq !== undefined) return `<span class="math-num">${p.sq}</span><sup style="font-size:16px;font-weight:700">2</sup>`;
      return `<span class="math-num">${p.n}</span>`;
    }).join('');

    const wrong = [...new Set([ans+r(7)+1, ans-r(7)-1, ans+r(3)*3+3, ans+r(5)+8])].filter(x=>x!==ans&&x>0);
    const opts = shu([ans, ...wrong.slice(0,3)]).map(String);

    return {
      q: 'Реши <b>в уме</b> слева направо',
      vis: `<div class="math-chain">${html}<span class="math-op">=</span><span style="font-size:30px;color:var(--text3);font-weight:700">?</span></div>`,
      ans: String(ans), opts
    };
  }
};
