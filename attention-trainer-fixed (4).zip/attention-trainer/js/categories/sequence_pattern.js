/* ── SEQUENCE ── */
CATS.sequence = {
  name: 'Числовые ряды', desc: 'Найди пропущенное число',
  icon: '🔢', bg: '#faece7', fg: '#712b13',
  gen() {
    const lvl = getLvl();
    const len = lvl.seqLen[0] + r(lvl.seqLen[1] - lvl.seqLen[0] + 1);

    const fns = [
      // Lvl 1: арифметика
      () => { const s=r(10)+2, d=r(8)+3, pos=r(len-2)+1, n=[]; for(let i=0;i<len;i++) n.push(s+d*i); const a=n[pos]; n[pos]='?'; return {n,a,hint:'арифм. прогрессия'}; },
      // Lvl 1: убывающая
      () => { const s=r(30)+30, d=r(6)+3, pos=r(len-2)+1, n=[]; for(let i=0;i<len;i++) n.push(s-d*i); const a=n[pos]; n[pos]='?'; return {n,a,hint:'убывающая'}; },
      // Lvl 2: геометрическая
      () => { const s=r(3)+2, rt=r(2)+2, pos=r(len-3)+1, n=[]; let v=s; for(let i=0;i<len;i++){n.push(v);v*=rt;} const a=n[pos]; n[pos]='?'; return {n,a,hint:'геометр. прогрессия'}; },
      // Lvl 2: квадраты
      () => { const off=r(3), n=[]; for(let i=1;i<=len;i++) n.push((i+off)*(i+off)); const pos=r(len-2)+1; const a=n[pos]; n[pos]='?'; return {n,a,hint:'квадраты чисел'}; },
      // Lvl 3: фибоначчи-подобная
      () => { const a0=r(5)+1, a1=r(5)+2, n=[a0,a1]; for(let i=2;i<len;i++) n.push(n[i-1]+n[i-2]); const pos=r(len-3)+2; const a=n[pos]; n[pos]='?'; return {n,a,hint:'каждое = сумма двух предыдущих'}; },
      // Lvl 3: чередование двух шагов
      () => { const s=r(10)+5, d1=r(7)+3, d2=-(r(3)+1), n=[]; let v=s; for(let i=0;i<len;i++){n.push(v);v+=(i%2===0?d1:d2);} const pos=r(len-3)+2; const a=n[pos]; n[pos]='?'; return {n,a,hint:'два чередующихся шага'}; },
      // Lvl 4: разности второго порядка
      () => { const s=r(5)+1, d=r(3)+2, n=[]; for(let i=0;i<len;i++) n.push(s+d*i+i*i); const pos=r(len-3)+2; const a=n[pos]; n[pos]='?'; return {n,a,hint:'разности разностей постоянны'}; },
      // Lvl 4: простые числа
      () => { const primes=[2,3,5,7,11,13,17,19,23,29,31,37,41,43,47]; const start=r(primes.length-len); const n=primes.slice(start,start+len); const pos=r(len-2)+1; const a=n[pos]; n[pos]='?'; return {n,a,hint:'простые числа'}; },
    ];
    const avail = lvl.id===1?fns.slice(0,2):lvl.id===2?fns.slice(0,4):lvl.id===3?fns.slice(0,6):fns;
    const {n, a, hint} = pick(avail)();
    const wrong = [...new Set([a+r(7)+1, a-r(7)-1, a+r(3)*2+2, a*2])].filter(x => x !== a && x > 0);
    return {
      q: 'Найди пропущенное число',
      vis: `<div style="text-align:center">
        <div style="font-size:28px;font-weight:700;letter-spacing:3px;line-height:1.8">${n.join(' — ')}</div>
      </div>`,
      ans: String(a), opts: shu([a, ...wrong.slice(0,3)]).map(String)
    };
  }
};

/* ── PATTERN ── */
CATS.pattern = {
  name: 'Паттерны', desc: 'Продолжи последовательность',
  icon: '🔄', bg: '#eaf3de', fg: '#27500a',
  gen() {
    const lvl = getLvl();
    const rules = [
      // Lvl 1
      () => { const e=['🔴','🔵','🟢'], s=[...e,...e,'?']; return {s,a:e[0],opts:shu([e[0],e[1],e[2],'🟡'])}; },
      () => { const e=['△','○','□'], n=[...e,...e.slice(0,2),'?']; return {s:n,a:'□',opts:shu(['□','△','○','◇'])}; },
      // Lvl 2
      () => { const e=['🌕','🌖','🌗','🌘'], s=[...e,...e.slice(0,3),'?']; return {s,a:e[3],opts:shu([...e])}; },
      () => { const st=r(4)+2,d=3,n=[]; for(let i=0;i<6;i++) n.push(st+d*i); n.push('?'); const a=st+d*6; return {s:n,a:String(a),opts:shu([a,a+3,a-3,a+6]).map(String)}; },
      // Lvl 3 — два чередующихся правила
      () => {
        const a=r(5)+2, b=r(3)+2, n=[a];
        for(let i=1;i<7;i++) n.push(i%2===0?n[i-2]+a:n[i-2]+b);
        n.push('?');
        const ans=n[6]+a;
        return {s:n.slice(0,7),a:String(ans),opts:shu([ans,ans+b,ans-a,ans+a+1]).map(String)};
      },
      () => { const p=[2,3,5,7,11,13,17,19]; const st=r(3); const s=p.slice(st,st+5).concat(['?']); const ans=p[st+5]; return {s,a:String(ans),opts:shu([ans,ans+2,ans-2,ans+4]).map(String)}; },
      // Lvl 4 — разности второго порядка
      () => {
        const s=[1,2,4,7,11,16,'?'];
        return {s,a:'22',opts:shu(['22','20','23','21'])};
      },
      () => {
        // степени двойки вперемешку с арифметикой
        const s=[1,2,3,4,8,8,27,'?'];
        return {s,a:'16',opts:shu(['16','12','20','32'])};
      },
    ];
    const avail = lvl.id===1?rules.slice(0,2):lvl.id===2?rules.slice(0,4):lvl.id===3?rules.slice(0,6):rules;
    const {s, a, opts} = pick(avail)();
    return {
      q: 'Что стоит на месте <b>?</b>',
      vis: `<div style="font-size:28px;font-weight:700;text-align:center;line-height:1.8;letter-spacing:2px">${s.join(' → ')}</div>`,
      ans: String(a), opts: opts.map(String)
    };
  }
};
