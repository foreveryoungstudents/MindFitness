/* ── BIHEM HAND — Руки и знаки ── */
CATS.bihem_hand = {
  name: 'Руки и знаки', desc: 'Координация рук: повторяй жесты поочерёдно',
  icon: '✋', bg: '#eeedfe', fg: '#3c3489',
  gen() { return { type: 'bihem_hand' }; }
};

const BH_TONGUE_TWISTERS = [
  'Шла Саша по шоссе и сосала сушку',
  'Карл у Клары украл кораллы',
  'На дворе трава, на траве дрова',
  'Три дроворуба на трёх дворах рубят дрова',
  'Купи кипу пик, пик кипу купи',
  'Рапортовал, да не дорапортовал',
];

const BH_CONFIGS = [
  { reps: 5,  withClap: false, withCount: false, withTwister: false, timeSec: 30, label: 'Лёгкий — 5 повторений под счёт' },
  { reps: 10, withClap: true,  withCount: false, withTwister: false, timeSec: 45, label: 'Средний — 10 повторений с хлопком' },
  { reps: 15, withClap: true,  withCount: true,  withTwister: false, timeSec: 60, label: 'Сложный — 15 повторений, хлопки + обратный счёт' },
  { reps: 20, withClap: true,  withCount: false, withTwister: true,  timeSec: 75, label: 'Эксперт — 20 повторений, хлопки + скороговорка' },
];

function renderBihemHand() {
  const lvl = getLvl();
  const cfg = BH_CONFIGS[lvl.id - 1];
  const signs = ['✊','✋','✌️','🤙'];
  const L = pick(signs), R = pick(signs.filter(s => s !== L));
  const twister = cfg.withTwister ? pick(BH_TONGUE_TWISTERS) : null;
  STATE.scratch = { cfg, L, R, twister, started: false, finished: false };

  let instructions = `<div style="font-size:15px;line-height:1.8;color:var(--text2);text-align:left;max-width:320px;margin:12px auto">`;
  instructions += `<div>• Поочерёдно меняйте руки <b>${cfg.reps} раз</b></div>`;
  if (cfg.withClap) instructions += `<div>• Между сменами — <b>хлопок</b> в ладоши</div>`;
  if (cfg.withCount) {
    instructions += `<div>• Ведите <b>обратный счёт вслух</b>: ${cfg.reps}, ${cfg.reps-1}, …, 1</div>`;
  }
  if (twister) {
    instructions += `<div>• Ритмично повторяйте скороговорку:</div>`;
    instructions += `<div style="margin-left:12px;font-style:italic;color:var(--text)">"${twister}"</div>`;
  }
  instructions += `</div>`;

  document.getElementById('task-area').innerHTML = `
    <div class="task-q" style="font-size:16px">Повторите жесты поочерёдно, меняя руки</div>
    <div style="display:flex;justify-content:center;gap:40px;margin:16px 0">
      <div style="text-align:center">
        <div style="font-size:80px">${L}</div>
        <div style="font-size:13px;color:var(--text2);margin-top:6px">Левая рука</div>
      </div>
      <div style="text-align:center">
        <div style="font-size:80px">${R}</div>
        <div style="font-size:13px;color:var(--text2);margin-top:6px">Правая рука</div>
      </div>
    </div>
    ${instructions}
    <div style="text-align:center;margin-top:12px">
      <button class="next-btn" id="bh-start-btn" onclick="bhStart()">▶ Начать упражнение</button>
    </div>
    <div id="bh-timer-wrap" style="display:none;margin-top:16px">
      <div style="font-size:13px;color:var(--text3);text-align:center;margin-bottom:6px">${cfg.label}</div>
      <div class="tim-bar-wrap"><div class="tim-bar" id="tim-bar"></div></div>
      <div id="bh-counter" style="font-size:20px;font-weight:700;text-align:center;margin-top:10px;color:var(--accent)"></div>
    </div>
    <div id="bh-done-btn" style="display:none;text-align:center;margin-top:14px">
      <button class="next-btn" onclick="bhFinish()">✓ Завершить упражнение</button>
    </div>`;
}

function bhStart() {
  const sc = STATE.scratch;
  const cfg = sc.cfg;
  document.getElementById('bh-start-btn').closest('div').style.display = 'none';
  document.getElementById('bh-timer-wrap').style.display = 'block';

  const total = cfg.timeSec;
  let elapsed = 0;
  const bar = document.getElementById('tim-bar');
  const counter = document.getElementById('bh-counter');

  // Счётчик: обратный отсчёт повторений или обратный счёт слов
  let repCount = cfg.withCount ? cfg.reps : cfg.reps;

  const iv = setInterval(() => {
    elapsed++;
    const pct = Math.min(100, elapsed / total * 100);
    if (bar) bar.style.width = pct + '%';

    // Каждые (timeSec/reps) секунд — один «тик» повторения
    const tickInterval = total / cfg.reps;
    const curRep = Math.floor(elapsed / tickInterval);
    const remaining = cfg.reps - curRep;
    if (counter) {
      counter.textContent = cfg.withCount
        ? (remaining > 0 ? remaining : '!')
        : `${Math.max(0, remaining)} / ${cfg.reps}`;
    }

    if (elapsed >= total) {
      clearInterval(iv);
      if (bar) bar.style.width = '100%';
      if (counter) counter.textContent = 'Завершите упражнение';
      document.getElementById('bh-done-btn').style.display = 'block';
    }
  }, 1000);

  sc._iv = iv;
}

function bhFinish() {
  const sc = STATE.scratch;
  if (sc._iv) clearInterval(sc._iv);
  if (STATE.answered) return;
  STATE.answered = true; stopTimer(); STATE.scOk++; STATE.scTot++;
  recordResult(true);
  updScore();
  document.getElementById('bh-done-btn').style.display = 'none';
  showFb(true, '');
  document.getElementById('nxt-btn').style.display = 'block';
}
