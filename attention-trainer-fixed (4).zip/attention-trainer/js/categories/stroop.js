/* ── STROOP ── */
CATS.stroop = {
  name: 'Тест Струпа', desc: 'Назови ЦВЕТ чернил, игнорируя слово',
  icon: '🎨', bg: '#eeedfe', fg: '#3c3489',
  gen() {
    const lvl = getLvl();
    const C4 = ['красный','синий','зелёный','жёлтый'];
    const C6 = [...C4, 'фиолетовый','оранжевый'];
    const K = { красный:'#d85a30', синий:'#378add', зелёный:'#639922', жёлтый:'#ba7517', фиолетовый:'#6d4aaa', оранжевый:'#d4700a' };
    const pool = lvl.id >= 3 ? C6 : C4;
    const w = pick(pool), ink = pick(pool.filter(c => c !== w));
    const distract = lvl.id === 4;
    const extraHtml = distract
      ? `<div style="font-size:15px;color:var(--text3);margin-top:10px">фон: <span style="color:${K[pick(pool.filter(c=>c!==w&&c!==ink))]};font-weight:600">фон</span></div>`
      : '';
    // opts: 4 варианта-цвета, ans (ink) гарантирован
    const opts = shu([...new Set([ink, w, ...pool])]).slice(0, 4);
    return {
      q: 'Каким <b>цветом</b> написано слово? (не читай — смотри на цвет!)',
      vis: `<div style="text-align:center">
        <span style="font-size:${lvl.id >= 3 ? 52 : 58}px;font-weight:700;color:${K[ink]}">${w}</span>
        ${extraHtml}
      </div>`,
      ans: ink,
      opts
    };
  }
};
