/* ── GRID MEMORY ── */
CATS.grid_memory = {
  name: 'Сетка по памяти', desc: 'Запомни закрашенные клетки и воспроизведи',
  icon: '🟦', bg: '#e6f1fb', fg: '#0c447c',
  gen() { return { type: 'grid_memory' }; }
};

// Палитра — один насыщенный цвет на всё задание, выбирается рандомно
const GM_PALETTES = [
  { fill:'#4e8ef7', sel:'#a8c8fb', bg:'#ddeeff' },  // синий
  { fill:'#3bb87a', sel:'#96dbb9', bg:'#d6f5e7' },  // зелёный
  { fill:'#e05c8a', sel:'#f0a8c0', bg:'#fde6ef' },  // розовый
  { fill:'#e07c30', sel:'#f0bc90', bg:'#fdeedd' },  // оранжевый
  { fill:'#7c5cbf', sel:'#bba8e0', bg:'#ede6f8' },  // фиолетовый
];

function renderGridMemory() {
  const lvl = getLvl();
  const configs = [
    { sz: 3, nFill: 3, secs: 5 },
    { sz: 4, nFill: 5, secs: 4 },
    { sz: 5, nFill: 8, secs: 4 },
    { sz: 5, nFill: 11, secs: 3 },
  ];
  const { sz, nFill, secs } = configs[lvl.id - 1];
  const tot = sz * sz;
  const cells = shu([...Array(tot)].map((_, i) => i)).slice(0, nFill).sort((a,b) => a-b);
  const pal = pick(GM_PALETTES);
  STATE.scratch = { pattern: cells, sz, nFill, selected: new Set(), pal };

  const cw = Math.min(62, Math.floor(300 / sz));

  document.getElementById('task-area').innerHTML = `
    <div class="task-q">Запомни закрашенные клетки</div>
    <div class="mgrid" id="mg" style="grid-template-columns:repeat(${sz},${cw}px);max-width:${sz*(cw+4)+10}px;margin:0 auto 1rem;"></div>
    <div class="mem-cd" id="mem-cd">${secs}</div>
    <div style="font-size:14px;color:var(--text3);text-align:center">секунд на запоминание</div>`;

  const mg = document.getElementById('mg');
  for (let i = 0; i < tot; i++) {
    const d = document.createElement('div');
    d.className = 'mcell';
    d.style.cssText = `width:${cw}px;height:${cw}px;background:${cells.includes(i)?pal.fill:pal.bg};border-color:${cells.includes(i)?pal.fill:'transparent'}`;
    mg.appendChild(d);
  }

  let s = secs;
  const iv = setInterval(() => {
    s--;
    const el = document.getElementById('mem-cd');
    if (el) el.textContent = s;
    if (s <= 0) { clearInterval(iv); renderGridRecall(sz, cw); }
  }, 1000);
}

function renderGridRecall(sz, cw) {
  const { pattern, selected, pal } = STATE.scratch;
  const tot = sz * sz;
  document.getElementById('task-area').innerHTML = `
    <div class="task-q">Отметь клетки, которые были закрашены</div>
    <div class="mgrid" id="mg2" style="grid-template-columns:repeat(${sz},${cw}px);max-width:${sz*(cw+4)+10}px;margin:0 auto 1rem;"></div>
    <div style="text-align:center">
      <button class="next-btn" onclick="checkGridMemory()">Проверить</button>
    </div>`;

  const mg = document.getElementById('mg2');
  for (let i = 0; i < tot; i++) {
    const d = document.createElement('div');
    d.className = 'mcell';
    d.style.cssText = `width:${cw}px;height:${cw}px;background:${pal.bg};border-color:transparent;cursor:pointer`;
    d.onclick = () => {
      if (STATE.answered) return;
      if (selected.has(i)) {
        selected.delete(i);
        d.style.background = pal.bg;
        d.style.borderColor = 'transparent';
      } else {
        selected.add(i);
        d.style.background = pal.sel;
        d.style.borderColor = pal.fill;
      }
    };
    mg.appendChild(d);
  }
  document.getElementById('nxt-btn').style.display = 'none';
}

function checkGridMemory() {
  if (STATE.answered) return;
  STATE.answered = true; STATE.scTot++;
  const { pattern, selected, pal } = STATE.scratch;
  const correct = new Set(pattern);
  const cells = document.getElementById('mg2').querySelectorAll('.mcell');
  let ok = true;
  cells.forEach((c, i) => {
    if (correct.has(i) && selected.has(i)) {
      // правильно выбрана — насыщенный цвет темы
      c.style.background = pal.fill; c.style.borderColor = pal.fill;
    } else if (correct.has(i) && !selected.has(i)) {
      // пропущена — бледный цвет темы (подсказка)
      c.style.background = pal.sel; c.style.borderColor = pal.fill;
      ok = false;
    } else if (!correct.has(i) && selected.has(i)) {
      // лишняя — серая
      c.style.background = '#bbb'; c.style.borderColor = '#999';
      ok = false;
    } else {
      // пустая и не выбрана — фон
      c.style.background = pal.bg; c.style.borderColor = 'transparent';
    }
  });
  if (ok) STATE.scOk++;
  recordResult(ok);
  document.querySelector('[onclick="checkGridMemory()"]').remove();
  showFb(ok, ok ? '' : `Правильно: ${pattern.filter(i => selected.has(i)).length}/${pattern.length}`);
  updScore();
  document.getElementById('nxt-btn').style.display = 'block';
}
