/* ── TEXT ATTENTION ── */
CATS.text_attn = {
  name: 'Внимание в тексте', desc: 'Найди нужные слова в тексте',
  icon: '📝', bg: '#f1efe8', fg: '#444441',
  gen() { return { type: 'text_attn' }; }
};

const TEXT_TASKS_ALL = [
  // Lvl 1
  { par: 'Мама мыла раму. Рядом стояла кошка. Кошка смотрела в окно. За окном шёл дождь. Дождь барабанил по стеклу. Стекло запотело. Мама вытерла стекло тряпкой. Тряпка намокла. Кошка зевнула и ушла спать.',
    q: 'Нажми на все слова с буквой <b>о</b>', lvl: 1, test: w => w.replace(/[^а-яёА-ЯЁ]/g,'').toLowerCase().includes('о') },
  { par: 'Пять котят сидели на крыше. Три котёнка были рыжими. Два котёнка были серыми. Все котята смотрели вниз. Один котёнок прыгнул вниз.',
    q: 'Нажми на все <b>числительные</b>', lvl: 1, test: w => ['пять','три','два','все','один'].includes(w.toLowerCase().replace(/[^а-яё]/g,'')) },
  // Lvl 2
  { par: 'Весна пришла внезапно. Солнце стало греть сильнее. Птицы вернулись с юга. Деревья покрылись листьями. Дети вышли гулять на улицу. Воздух пах цветами и свежестью.',
    q: 'Нажми на все <b>глаголы</b>', lvl: 2, test: w => ['пришла','стало','вернулись','покрылись','вышли','пах'].includes(w.toLowerCase().replace(/[^а-яё]/g,'')) },
  { par: 'Синий шар летел над городом. В городе жили добрые люди. Люди смотрели на чистое небо. Небо было ясным и безоблачным. Чистый воздух приятно пах. Пахло цветами и влажной травой.',
    q: 'Нажми на все <b>прилагательные</b>', lvl: 2, test: w => ['синий','добрые','чистое','ясным','безоблачным','чистый','влажной'].includes(w.toLowerCase().replace(/[^а-яё]/g,'')) },
  // Lvl 3 — повторяющиеся слова, требует счёта
  { par: 'Река несла холодную воду в море. Рыбы плескались у берега. Берег был покрыт мелким песком. Песок блестел на солнце. Солнце клонилось к горизонту. Горизонт пылал красным.',
    q: 'Нажми на слова, которые встречаются в тексте <b>дважды</b>', lvl: 3, test: w => ['берег','песок','солнце','горизонт'].includes(w.toLowerCase().replace(/[^а-яё]/g,'')) },
  { par: 'Наука требует точности. Точность — основа любого знания. Знание без понимания мертво. Понимание приходит через опыт. Опыт — это то, что остаётся, когда забываешь всё остальное.',
    q: 'Нажми на слова, которые перекликаются с <b>концом предыдущего предложения</b>', lvl: 3, test: w => ['точность','знания','понимание','опыт'].includes(w.toLowerCase().replace(/[^а-яё]/g,'')) },
  // Lvl 4 — сложные грамматические признаки
  { par: 'Поэт с восторгом писал пером по бумаге. Он дышал свежим воздухом и любовался закатом. Художник за соседним столом работал кистью с непоколебимым упорством.',
    q: 'Нажми на все слова в <b>творительном падеже</b> (кем? чем?)', lvl: 4, test: w => ['восторгом','пером','бумаге','воздухом','закатом','кистью','упорством'].includes(w.toLowerCase().replace(/[^а-яё]/g,'')) },
  { par: 'Вселенная расширяется с ускорением. Тёмная энергия противодействует гравитации. Фотоны путешествуют через миллиарды световых лет. Астрономы фиксируют реликтовое излучение и строят модели.',
    q: 'Нажми на все слова <b>иноязычного происхождения</b>', lvl: 4, test: w => ['вселенная','энергия','фотоны','астрономы','реликтовое','модели','гравитации'].includes(w.toLowerCase().replace(/[^а-яё]/g,'')) },
];

function renderTextAttn() {
  const lvl = getLvl();
  const avail = TEXT_TASKS_ALL.filter(t => t.lvl <= lvl.id);
  const t = pick(avail.length ? avail : TEXT_TASKS_ALL);
  const words = t.par.split(/(\s+)/);
  const total = words.filter(w => t.test(w)).length;
  const html = words.map(w => {
    if (/^\s+$/.test(w) || !w.trim()) return w;
    return `<span class="tw" data-tgt="${t.test(w) ? 1 : 0}" onclick="twClick(this)">${w}</span>`;
  }).join('');
  document.getElementById('task-area').innerHTML = `
    <div class="task-q" style="font-size:16px">${t.q}</div>
    <div class="task-vis" style="text-align:left;font-size:17px;line-height:2.2">${html}</div>
    <div class="sc-info" id="txt-prog" style="margin-top:8px;font-size:14px">Найдено: 0 из ${total}</div>`;
  STATE.scratch = { total, found: 0, done: false };
}

function twClick(el) {
  if (el.classList.contains('hit') || STATE.scratch.done) return;
  if (el.dataset.tgt === '1') {
    el.classList.add('hit');
    STATE.scratch.found++;
    document.getElementById('txt-prog').textContent = `Найдено: ${STATE.scratch.found} из ${STATE.scratch.total}`;
    if (STATE.scratch.found >= STATE.scratch.total) {
      STATE.scratch.done = true;
      STATE.answered = true; STATE.scOk++; STATE.scTot++;
      recordResult(true);
      updScore(); showFb(true, '');
      document.getElementById('nxt-btn').style.display = 'block';
      document.querySelectorAll('.tw:not(.hit)').forEach(e => { if (e.dataset.tgt === '1') e.classList.add('show'); });
    }
  } else {
    el.classList.add('mis');
    setTimeout(() => el.classList.remove('mis'), 400);
  }
}

/* ── ANAGRAM ── */
CATS.anagram = {
  name: 'Анаграммы', desc: 'Собери слово из перемешанных букв',
  icon: '🔤', bg: '#eeedfe', fg: '#3c3489',
  gen() {
    const lvl = getLvl();
    const words = [
      // Lvl 1 — 4-5 букв, известные слова
      // Все слова минимум 7 букв
      { w: 'ЯБЛОКО',   h: 'Фрукт',              lvl: 1 },
      { w: 'СОЛНЦЕ',   h: 'Звезда',             lvl: 1 },
      { w: 'ЛОШАДЬ',   h: 'Животное',           lvl: 1 },
      { w: 'КАПУСТА',  h: 'Овощ',               lvl: 1 },
      { w: 'КОРАБЛЬ',  h: 'В море',             lvl: 2 },
      { w: 'СТАРИНА',  h: 'Древность',          lvl: 2 },
      { w: 'ГИТАРА',   h: 'Инструмент',         lvl: 2 },
      { w: 'ТАБЛИЦА',  h: 'В математике',       lvl: 2 },
      { w: 'РАСТВОР',  h: 'В химии',            lvl: 3 },
      { w: 'КАТАЛОГ',  h: 'Список',             lvl: 3 },
      { w: 'РЕКОРД',   h: 'Достижение',         lvl: 3 },
      { w: 'ТЕАТРАЛ',  h: 'Любитель театра',    lvl: 3 },
      { w: 'ПЛАНЕТА',  h: 'В космосе',          lvl: 4 },
      { w: 'АКВАРЕЛЬ', h: 'Краски',             lvl: 4 },
      { w: 'КАРНАВАЛ', h: 'Праздник',           lvl: 4 },
      { w: 'ЛАБОРАНТ', h: 'В лаборатории',      lvl: 4 },
      { w: 'КИНОЛЕНТ', h: 'Лента фильма',       lvl: 4 },
      { w: 'КОЛОКОЛ',  h: 'Звонит',             lvl: 4 },
    ];
    const avail = words.filter(x => x.lvl <= lvl.id);
    const { w, h } = pick(avail);
    return { type: 'anagram', word: w, letters: shu(w.split('')), hint: h };
  }
};

function renderAnagram() {
  const t = STATE.curTask;
  STATE.scratch = { answer: [] };

  function refresh() {
    const ans = STATE.scratch.answer;
    const tileHTML = t.letters.map((l, i) =>
      `<div class="ana-tile${ans.includes(i) ? ' used' : ''}" onclick="anaClick(${i})">${l}</div>`
    ).join('');
    const slotHTML = ans.length
      ? ans.map(idx => `<div class="ana-slot" onclick="anaRm(${idx})" title="убрать">${t.letters[idx]}</div>`).join('')
      : `<div style="color:var(--text3);font-size:14px;align-self:center;padding:4px">нажимай буквы</div>`;
    document.getElementById('ana-tiles').innerHTML = tileHTML;
    document.getElementById('ana-slots').innerHTML = slotHTML;
    if (!STATE.answered && ans.map(i => t.letters[i]).join('') === t.word) {
      STATE.answered = true; stopTimer(); STATE.scOk++; STATE.scTot++;
      recordResult(true);
      updScore(); showFb(true, t.word);
      document.getElementById('nxt-btn').style.display = 'block';
    }
  }
  window.anaClick = i => { if (!STATE.scratch.answer.includes(i)) { STATE.scratch.answer.push(i); refresh(); } };
  window.anaRm = i => { STATE.scratch.answer = STATE.scratch.answer.filter(x => x !== i); refresh(); };

  document.getElementById('task-area').innerHTML = `
    <div class="task-q">Составь слово из букв<br><span style="font-size:14px;color:var(--text2)">Подсказка: ${t.hint}</span></div>
    <div class="anagram-letters" id="ana-tiles"></div>
    <div class="anagram-answer" id="ana-slots"></div>
    <div style="text-align:center;margin-top:8px"><button class="btn-sm" onclick="anaReset()">Сбросить</button></div>`;
  window.anaReset = () => { STATE.scratch.answer = []; refresh(); };
  refresh();
  startTimer(60);
}

/* ── SPEECH ODD ── */
CATS.speech_odd = {
  name: 'Лишнее слово', desc: 'Найди слово, лишнее по смыслу',
  icon: '🚫', bg: '#faece7', fg: '#712b13',
  gen() {
    const lvl = getLvl();
    const groups = [
      // Lvl 1
      { items:['кошка','собака','лиса','ромашка','волк'],       odd:'ромашка',   reason:'Не животное',                  lvl:1 },
      { items:['январь','февраль','среда','март','апрель'],      odd:'среда',     reason:'День недели, не месяц',        lvl:1 },
      { items:['молоко','кефир','сок','йогурт','сметана'],       odd:'сок',       reason:'Не молочный продукт',          lvl:1 },
      // Lvl 2
      { items:['красный','синий','тяжёлый','зелёный','жёлтый'], odd:'тяжёлый',   reason:'Не цвет, а признак-вес',       lvl:2 },
      { items:['Москва','Лондон','Париж','Нева','Берлин'],       odd:'Нева',      reason:'Река, не столица',             lvl:2 },
      { items:['скрипка','виолончель','альт','гобой','виола'],   odd:'гобой',     reason:'Духовой, остальные — смычковые', lvl:2 },
      // Lvl 3
      { items:['Толстой','Пушкин','Чехов','Репин','Достоевский'],odd:'Репин',    reason:'Художник, не писатель',        lvl:3 },
      { items:['самолёт','поезд','пароход','велосипед','ракета'],odd:'велосипед', reason:'Мускульная тяга, не мотор',   lvl:3 },
      { items:['нейтрон','протон','электрон','атом','позитрон'], odd:'атом',      reason:'Не субатомная частица',        lvl:3 },
      { items:['Бах','Моцарт','Сальери','Вивальди','Гендель'],   odd:'Сальери',   reason:'Не создал значимых шедевров', lvl:3 },
      // Lvl 4 — тонкие различия
      { items:['гипотеза','аксиома','теорема','постулат','лемма'],odd:'гипотеза', reason:'Не доказана, остальные — истинны по определению или доказаны', lvl:4 },
      { items:['Юнг','Фрейд','Адлер','Ясперс','Хорни'],          odd:'Ясперс',    reason:'Экзистенциальный философ-психиатр, остальные — психоаналитики фрейдистской школы', lvl:4 },
      { items:['сонет','рондо','газель','баллада','хайку'],       odd:'рондо',     reason:'Музыкальная форма, а не стихотворная', lvl:4 },
      { items:['реализм','романтизм','импрессионизм','кубизм','барокко'],odd:'импрессионизм',reason:'Остальные имеют чёткую философскую программу, импрессионизм — визуальный метод', lvl:4 },
    ];
    const avail = groups.filter(g => g.lvl <= lvl.id);
    const g = pick(avail);
    return { q: 'Найди <b>лишнее</b> слово', type:'speech_odd', items: shu(g.items), odd: g.odd, reason: g.reason };
  }
};
