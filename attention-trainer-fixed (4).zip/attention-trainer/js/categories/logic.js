/* ── ANALOGY ── */
CATS.analogy = {
  name: 'Аналогии', desc: 'Реши словесную аналогию',
  icon: '⚖️', bg: '#eaf3de', fg: '#27500a',
  gen() {
    const lvl = getLvl();
    const tasks = [
      // Уровень 1 — предметные, очевидные
      { a:'птица',    b:'перья',      c:'рыба',         ans:'чешуя',        w:['плавники','вода','хвост'],          lvl:1 },
      { a:'нож',      b:'резать',     c:'игла',          ans:'шить',         w:['острый','ткань','металл'],          lvl:1 },
      { a:'художник', b:'кисть',      c:'скульптор',     ans:'резец',        w:['глина','музей','руки'],             lvl:1 },
      { a:'день',     b:'солнце',     c:'ночь',          ans:'луна',         w:['темнота','звёзды','сон'],           lvl:1 },
      // Уровень 2 — функциональные связи
      { a:'термометр',b:'температура',c:'барометр',      ans:'давление',     w:['погода','воздух','стекло'],         lvl:2 },
      { a:'дирижёр',  b:'оркестр',   c:'режиссёр',      ans:'труппа',       w:['сцена','фильм','зритель'],          lvl:2 },
      { a:'Луна',     b:'Земля',      c:'Земля',         ans:'Солнце',       w:['звезда','галактика','орбита'],      lvl:2 },
      { a:'слово',    b:'буква',      c:'фраза',         ans:'слово',        w:['предложение','текст','знак'],       lvl:2 },
      { a:'глагол',   b:'действие',   c:'существительное',ans:'предмет',     w:['слово','буква','часть речи'],       lvl:2 },
      // Уровень 3 — абстрактные / научные
      { a:'центр',    b:'окружность', c:'фокус',         ans:'эллипс',       w:['парабола','прямая','дуга'],         lvl:3 },
      { a:'Гомер',    b:'эпос',       c:'Шекспир',       ans:'драма',        w:['трагедия','роман','сонет'],         lvl:3 },
      { a:'гипотеза', b:'теория',     c:'симптом',       ans:'диагноз',      w:['болезнь','лечение','анализ'],       lvl:3 },
      { a:'частное',  b:'деление',    c:'произведение',  ans:'умножение',    w:['сложение','степень','корень'],      lvl:3 },
      { a:'Бах',      b:'барокко',    c:'Малевич',       ans:'авангард',     w:['импрессионизм','реализм','сюрр.'], lvl:3 },
      // Уровень 4 — межпредметные, неочевидные
      { a:'нейрон',   b:'мозг',       c:'атом',          ans:'вещество',     w:['молекула','ядро','элемент'],        lvl:4 },
      { a:'Кеплер',   b:'орбиты',     c:'Мендель',       ans:'наследственность',w:['гены','эволюция','клетка'],    lvl:4 },
      { a:'синтез',   b:'анализ',     c:'дедукция',      ans:'индукция',     w:['вывод','логика','суждение'],        lvl:4 },
      { a:'энтропия', b:'беспорядок', c:'негэнтропия',   ans:'порядок',      w:['система','хаос','информация'],     lvl:4 },
      { a:'сонет',    b:'14 строк',   c:'хокку',         ans:'17 слогов',    w:['3 строки','природа','японское'],   lvl:4 },
    ];
    const avail = tasks.filter(t => t.lvl <= lvl.id);
    const t = pick(avail);
    return {
      q: 'Продолжи по аналогии',
      vis: `<div class="analogy-parts">
        <span class="a-kw">${t.a}</span><span class="a-rel">→</span>
        <span class="a-kw">${t.b}</span><span class="a-rel">=</span>
        <span class="a-kw">${t.c}</span><span class="a-rel">→</span>
        <span class="a-q">?</span>
      </div>`,
      ans: t.ans, opts: shu([t.ans, ...t.w.slice(0,3)])
    };
  }
};

/* ── EXCEPT ── */
CATS.except = {
  name: '4-й лишний', desc: 'Найди предмет, не входящий в группу',
  icon: '❌', bg: '#fbeaf0', fg: '#72243e',
  gen() {
    const lvl = getLvl();
    const sets = [
      // Уровень 1 — очевидные категории
      { items:['волк','тигр','лиса','орёл'],               odd:'орёл',        why:'Птица, не млекопитающее', lvl:1 },
      { items:['суп','каша','борщ','чай'],                  odd:'чай',         why:'Напиток, не блюдо',       lvl:1 },
      { items:['2','4','6','9'],                             odd:'9',           why:'Нечётное число',          lvl:1 },
      { items:['берёза','дуб','сосна','рябина'],             odd:'сосна',       why:'Хвойное дерево',          lvl:1 },
      // Уровень 2 — менее очевидно
      { items:['молоток','пила','гвоздь','отвёртка'],        odd:'гвоздь',      why:'Не инструмент, а крепёж', lvl:2 },
      { items:['Луна','Марс','Венера','Комета'],              odd:'Комета',      why:'Не планета и не спутник', lvl:2 },
      { items:['флейта','гобой','скрипка','кларнет'],        odd:'скрипка',     why:'Смычковый, не духовой',   lvl:2 },
      { items:['Амазонка','Нил','Байкал','Волга'],           odd:'Байкал',      why:'Озеро, не река',          lvl:2 },
      { items:['квадрат','круг','треугольник','куб'],        odd:'куб',         why:'Трёхмерная фигура',       lvl:2 },
      // Уровень 3 — требует знаний
      { items:['вирус','бактерия','грибок','антибиотик'],    odd:'антибиотик',  why:'Не микроорганизм',        lvl:3 },
      { items:['5','7','11','9'],                             odd:'9',           why:'Не простое (9 = 3×3)',    lvl:3 },
      { items:['Эйнштейн','Ньютон','Дарвин','Рафаэль'],     odd:'Рафаэль',     why:'Художник, не учёный',     lvl:3 },
      { items:['Шопен','Лист','Паганини','Вагнер'],          odd:'Паганини',    why:'Скрипач, не пианист',     lvl:3 },
      { items:['Гоголь','Булгаков','Кафка','Толстой'],       odd:'Толстой',     why:'Реалист, остальные — сюрреализм/абсурд', lvl:3 },
      // Уровень 4 — спорные, требуют аргументации
      { items:['нейтрон','протон','электрон','атом'],        odd:'атом',        why:'Не элементарная частица', lvl:4 },
      { items:['Сократ','Платон','Аристотель','Архимед'],   odd:'Архимед',     why:'Математик, не философ',   lvl:4 },
      { items:['ДНК','РНК','белок','глюкоза'],              odd:'глюкоза',     why:'Не биополимер',           lvl:4 },
      { items:['сонет','терцина','газель','верлибр'],        odd:'верлибр',     why:'Нет чёткой рифмовки/метра', lvl:4 },
      { items:['Рембрандт','Вермер','Хальс','Рубенс'],      odd:'Рубенс',      why:'Фламандец, остальные — нидерландцы', lvl:4 },
    ];
    const avail = sets.filter(s => s.lvl <= lvl.id);
    const s = pick(avail);
    return { q: 'Найди <b>лишний</b> предмет', type:'except', items: shu(s.items), odd: s.odd, why: s.why };
  }
};

/* ── MATRIX LOGIC ── */
CATS.matrix_logic = {
  name: 'Матрица', desc: 'Найди закономерность в таблице',
  icon: '🔲', bg: '#e6f1fb', fg: '#0c447c',
  gen() {
    const lvl = getLvl();
    const td = (c, extra='') =>
      `<td style="border:2px solid var(--border2);padding:14px 10px;min-width:56px;text-align:center;font-size:26px;${extra}">${c}</td>`;
    const th = (c) =>
      `<td style="border:2px solid var(--border2);padding:10px;min-width:56px;text-align:center;font-size:13px;color:var(--text3);background:var(--surface2)">${c}</td>`;
    const blank = 'background:var(--accent-pale,#eef2ff);font-size:20px;color:var(--text3);font-weight:700';

    const tasks = [
      // Уровень 1 — числовые, нужно найти правило
      {
        vis:`<table style="border-collapse:collapse;margin:0 auto"><tr>${td('3')}${td('6')}${td('9')}</tr><tr>${td('5')}${td('10')}${td('15')}</tr><tr>${td('7')}${td('14')}${td('?',blank)}</tr></table>`,
        q:'Каждое число = первое в строке × номер столбца. Что на месте ?', ans:'21', opts:['21','17','28','14'], lvl:1
      },
      {
        vis:`<table style="border-collapse:collapse;margin:0 auto"><tr>${td('1')}${td('2')}${td('4')}</tr><tr>${td('2')}${td('4')}${td('8')}</tr><tr>${td('3')}${td('6')}${td('?',blank)}</tr></table>`,
        q:'Строка умножается на 2. Что пропущено?', ans:'12', opts:['12','9','10','15'], lvl:1
      },
      // Уровень 2 — суммы строк/столбцов
      {
        vis:`<table style="border-collapse:collapse;margin:0 auto"><tr>${td('4')}${td('7')}${td('2')}${th('13')}</tr><tr>${td('1')}${td('5')}${td('9')}${th('15')}</tr><tr>${td('6')}${td('3')}${td('?',blank)}${th('?')}</tr><tr>${th('11')}${th('15')}${th('?')}${th('')}</tr></table>`,
        q:'Суммы строк и столбцов показаны серым. Каково пропущенное число?', ans:'8', opts:['8','7','9','11'], lvl:2
      },
      {
        vis:`<table style="border-collapse:collapse;margin:0 auto"><tr>${td('2')}${td('3')}${td('5')}</tr><tr>${td('3')}${td('5')}${td('8')}</tr><tr>${td('5')}${td('8')}${td('?',blank)}</tr></table>`,
        q:'Каждое число = сумма двух предыдущих в том же направлении. Что пропущено?', ans:'13', opts:['13','11','15','16'], lvl:2
      },
      // Уровень 3 — множественные правила
      {
        vis:`<table style="border-collapse:collapse;margin:0 auto"><tr>${td('1')}${td('4')}${td('9')}${td('16')}</tr><tr>${td('2')}${td('8')}${td('18')}${td('32')}</tr><tr>${td('3')}${td('12')}${td('27')}${td('?',blank)}</tr></table>`,
        q:'Строка i, столбец j: i × j². Что пропущено?', ans:'48', opts:['48','36','54','42'], lvl:3
      },
      {
        vis:`<table style="border-collapse:collapse;margin:0 auto"><tr>${td('A')}${td('B')}${td('C')}</tr><tr>${td('Z')}${td('Y')}${td('X')}</tr><tr>${td('B')}${td('D')}${td('?',blank)}</tr></table>`,
        q:'Строка 1: алфавит вперёд. Строка 2: назад. Строка 3: через букву вперёд. Что пропущено?', ans:'F', opts:['F','E','G','H'], lvl:3
      },
      // Уровень 4 — нестандартные правила
      {
        vis:`<table style="border-collapse:collapse;margin:0 auto"><tr>${td('1')}${td('1')}${td('2')}${td('3')}</tr><tr>${td('1')}${td('2')}${td('3')}${td('5')}</tr><tr>${td('2')}${td('3')}${td('5')}${td('8')}</tr><tr>${td('3')}${td('5')}${td('8')}${td('?',blank)}</tr></table>`,
        q:'Числа Фибоначчи: каждая строка сдвинута. Что пропущено?', ans:'13', opts:['13','12','11','15'], lvl:4
      },
      {
        vis:`<table style="border-collapse:collapse;margin:0 auto"><tr>${td('2')}${td('3')}${td('5')}</tr><tr>${td('3')}${td('5')}${td('7')}</tr><tr>${td('5')}${td('7')}${td('?',blank)}</tr></table>`,
        q:'В каждой строке — три последовательных простых числа. Что пропущено?', ans:'11', opts:['11','9','13','10'], lvl:4
      },
    ];
    const avail = tasks.filter(t => t.lvl <= lvl.id);
    const t = pick(avail);
    return { q: t.q, vis: t.vis, ans: t.ans, opts: shu(t.opts) };
  }
};

/* ── Exception/speech renderer (shared) ── */
function renderExc() {
  const t = STATE.curTask;
  const odd = t.odd;
  const why = t.reason || t.why;
  document.getElementById('task-area').innerHTML = `
    <div class="task-q">${t.q}</div>
    <div class="exc-box">${t.items.map(w =>
      `<div class="exc-item" onclick="excClick(this,'${esc(w)}','${esc(odd)}','${esc(why)}')">${w}</div>`
    ).join('')}</div>`;
  startTimer(30);
}

function excClick(el, val, odd, why) {
  if (STATE.answered) return;
  STATE.answered = true; stopTimer(); STATE.scTot++;
  const ok = val === odd; if (ok) STATE.scOk++;
  recordResult(ok);
  el.classList.add(ok ? 'ok' : 'no');
  document.querySelectorAll('.exc-item').forEach(b => {
    b.onclick = null;
    if (b.textContent === odd) b.classList.add('ok');
  });
  const fb = document.getElementById('fb');
  fb.style.display = 'block'; fb.className = 'feedback ' + (ok ? 'ok' : 'no');
  fb.textContent = (ok ? '✓ Верно! ' : '✗ Лишнее: ' + odd + '. ') + why;
  updScore();
  document.getElementById('nxt-btn').style.display = 'block';
}
