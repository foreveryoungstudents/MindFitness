/* ── GHOST GAME — «Приведение» ── */
CATS.bihem_seq = {
  name: 'Приведение', desc: 'Найди эталонный образ на карточке',
  icon: '👻', bg: '#faeeda', fg: '#633806',
  gen() { return { type: 'ghost_game' }; }
};

// 5 эталонов: объект + цвет
const GHOST_REFS = [
  { obj: 'кресло',    color: 'красное',  emoji: '🪑', hex: '#e05c5c' },
  { obj: 'книга',     color: 'синяя',    emoji: '📘', hex: '#4e8ef7' },
  { obj: 'мышь',      color: 'серая',    emoji: '🐭', hex: '#999'    },
  { obj: 'приведение',color: 'белое',    emoji: '👻', hex: '#ddd'    },
  { obj: 'бутылка',   color: 'зелёная',  emoji: '🍾', hex: '#3bb87a' },
];

const ALL_OBJS   = GHOST_REFS.map(r => r.obj);
const ALL_COLORS = GHOST_REFS.map(r => r.color);
const COLOR_HEX  = Object.fromEntries(GHOST_REFS.map(r => [r.color, r.hex]));
const OBJ_EMOJI  = Object.fromEntries(GHOST_REFS.map(r => [r.obj, r.emoji]));

function renderGhostGame() {
  const lvl = getLvl();
  // Количество карточек для показа (сложность)
  const cardsN = [1, 2, 3, 4][lvl.id - 1];

  // Генерируем карточку: несколько объектов с рандомными цветами
  // Эталон есть с вероятностью 0.5
  const hasRef = Math.random() > 0.4;
  let refMatch = null;
  const cards = [];

  if (hasRef) {
    // Берём один рандомный эталон и помещаем его на карточку
    refMatch = pick(GHOST_REFS);
    cards.push({ obj: refMatch.obj, color: refMatch.color });
    // Добавляем ещё cardsN-1 NON-эталонных образов (неправильный цвет или не тот объект)
    for (let i = 1; i < cardsN; i++) {
      let obj, color;
      do {
        obj   = pick(ALL_OBJS);
        color = pick(ALL_COLORS.filter(c => c !== GHOST_REFS.find(r => r.obj === obj)?.color));
      } while (cards.some(c => c.obj === obj));
      cards.push({ obj, color });
    }
  } else {
    // Нет ни одного эталона — все неправильные комбинации
    const usedObjs = new Set();
    for (let i = 0; i < cardsN; i++) {
      let obj, color, isRef;
      do {
        obj   = pick(ALL_OBJS.filter(o => !usedObjs.has(o)));
        color = pick(ALL_COLORS);
        isRef = GHOST_REFS.some(r => r.obj === obj && r.color === color);
      } while (isRef);
      usedObjs.add(obj);
      cards.push({ obj, color });
    }
  }

  // Перемешиваем карточки
  shu(cards);

  // Определяем правильный ответ
  let ans, explanation;
  if (hasRef) {
    ans = `${refMatch.color} ${refMatch.obj}`;
    explanation = `✓ На карточке есть эталон: ${refMatch.color} ${refMatch.emoji}`;
  } else {
    // Найдём эталон, чьи оба признака (объект И цвет) полностью отсутствуют
    const presentObjs   = new Set(cards.map(c => c.obj));
    const presentColors = new Set(cards.map(c => c.color));
    const absent = GHOST_REFS.filter(r =>
      !presentObjs.has(r.obj) && !presentColors.has(r.color)
    );
    const chosen = absent.length > 0 ? pick(absent) : pick(GHOST_REFS.filter(r => !presentObjs.has(r.obj)));
    ans = `${chosen.color} ${chosen.obj}`;
    explanation = `Эталона нет. Полностью отсутствует: ${chosen.color} ${chosen.emoji}`;
  }

  // Строим варианты ответов
  const distractors = shu(GHOST_REFS.filter(r => `${r.color} ${r.obj}` !== ans))
    .slice(0, 3).map(r => `${r.color} ${r.obj}`);
  const opts = shu([ans, ...distractors]);

  STATE.scratch = { refs: GHOST_REFS, cards, ans, explanation, hasRef, shown: false };

  // Отображаем эталоны
  const refsHTML = GHOST_REFS.map(r =>
    `<div class="ghost-ref" style="border-color:${r.hex}">
      <span style="font-size:26px">${r.emoji}</span>
      <span style="font-size:11px;color:${r.hex};font-weight:600">${r.color}</span>
    </div>`
  ).join('');

  const cardsHTML = shu([...cards]).map(c =>
    `<div class="ghost-card" style="border-color:${COLOR_HEX[c.color]}">
      <div style="font-size:48px">${OBJ_EMOJI[c.obj]}</div>
      <div style="font-size:13px;font-weight:600;color:${COLOR_HEX[c.color]};margin-top:6px">${c.color}</div>
      <div style="font-size:13px;color:var(--text2)">${c.obj}</div>
    </div>`
  ).join('');

  const optHTML = opts.map(o => {
    const ref = GHOST_REFS.find(r => `${r.color} ${r.obj}` === o);
    return `<button class="opt" onclick="checkAns(this,'${esc(o)}','${esc(ans)}',true)">
      ${ref ? ref.emoji : ''} ${o}
    </button>`;
  }).join('');

  document.getElementById('task-area').innerHTML = `
    <div class="task-q" style="font-size:15px">Есть ли на карточке <b>эталонный образ</b>?<br>
      <span style="font-size:12px;color:var(--text3)">Эталон = точное совпадение объекта И цвета</span>
    </div>
    <div style="margin:10px 0 6px;font-size:12px;color:var(--text3);text-align:center">Эталоны:</div>
    <div style="display:flex;gap:8px;justify-content:center;flex-wrap:wrap;margin-bottom:16px">${refsHTML}</div>
    <div style="font-size:12px;color:var(--text3);text-align:center;margin-bottom:8px">Карточка:</div>
    <div style="display:flex;gap:12px;justify-content:center;flex-wrap:wrap;margin-bottom:16px">${cardsHTML}</div>
    <div class="opts">${optHTML}</div>`;
}
