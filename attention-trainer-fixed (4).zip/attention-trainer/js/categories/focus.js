/* ── FOCUS ── */
CATS.focus = {
  name: 'Концентрация', desc: 'Подсчитай нужные символы',
  icon: '👁', bg: '#e6f1fb', fg: '#0c447c',
  gen() {
    const lvl = getLvl();
    const counts = [20, 28, 36, 45];
    const total = counts[lvl.id - 1];
    // Уровень 3-4: похожие символы-ловушки, без подсветки целей
    const pools = [
      ['●','■','▲','◆'],
      ['●','■','▲','◆','★'],
      ['●','◉','◎','○','◌'],   // похожие круги — труднее различать
      ['■','▪','▫','□','▬'],   // похожие квадраты
    ];
    const pool = pools[lvl.id - 1];
    const tgt = pick(pool);
    const items = []; let cnt = 0;
    for (let i = 0; i < total; i++) {
      const s = pick(pool); items.push(s);
      if (s === tgt) cnt++;
    }
    const opts = shu([...new Set([cnt, cnt+1, Math.max(0,cnt-1), cnt+2])].slice(0,4));
    const sz = [38, 34, 32, 30][lvl.id - 1];
    const gap = [10, 8, 7, 6][lvl.id - 1];
    return {
      q: `Сколько символов <b style="font-size:${sz}px">${tgt}</b>?`,
      vis: `<div style="display:flex;flex-wrap:wrap;gap:${gap}px;justify-content:center;font-size:${sz}px;line-height:1.1">${
        items.map(s => `<span>${s}</span>`).join('')
      }</div>`,
      ans: String(cnt), opts: opts.map(String)
    };
  }
};
