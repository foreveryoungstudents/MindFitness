/* ── GRID SEARCH ── */
CATS.grid_search = {
  name: 'Поиск в сетке', desc: 'Найди все вхождения символа',
  icon: '🔍', bg: '#eaf3de', fg: '#27500a',
  gen() {
    const lvl = getLvl();
    const cols = [5, 6, 7, 8][lvl.id - 1];
    const rows = [4, 5, 5, 6][lvl.id - 1];
    const total = cols * rows;
    const maxHits = [7, 9, 11, 13][lvl.id - 1];

    // Уровни 3-4: зрительно похожие буквы — без цветовой подсветки целей
    const pools = [
      'АБВГДЕЖЗИКЛМНОПРСТУФХЦЧШЭЮЯ'.split(''),
      'АБВГДЕЖЗИКЛМНОПРСТУФХЦЧШЩЭЮЯ'.split(''),
      ['З','Э','С','О','С','З','Э'],   // похожие по форме
      ['Ш','Щ','Ш','И','Й','Н','П'],
    ];
    const pool = pools[Math.min(lvl.id - 1, pools.length - 1)];
    const tgt = pick(pool);
    const grid = []; let cnt = 0;
    for (let i = 0; i < total; i++) {
      if (Math.random() < 0.18 && cnt < maxHits) { grid.push(tgt); cnt++; }
      else { let s; do { s = pick(pool); } while (s === tgt); grid.push(s); }
    }
    const opts = shu([...new Set([cnt, cnt+1, Math.max(0,cnt-1), cnt+2])].slice(0,4));
    const sz = [28, 26, 24, 22][lvl.id - 1];
    return {
      q: `Сколько раз встречается <b style="font-size:${sz+6}px;font-family:monospace">${tgt}</b>?`,
      vis: `<div style="display:grid;grid-template-columns:repeat(${cols},1fr);gap:4px;font-family:monospace;font-size:${sz}px;text-align:center">${
        grid.map(c => `<span>${c}</span>`).join('')
      }</div>`,
      ans: String(cnt), opts: opts.map(String)
    };
  }
};
